#Austin Stewart
#Task 1
#date:10/16/2020


import functions


def main():
    #Starting point of the execution
    while True:
        try:
            total_persons = int(input("\nEnter number of sales persons to process: "))
            break
        except:
            print("Wrong Input.")
        
    sales_data = []

    # user inputs
    for i in range(total_persons):
        while True:
            try:
                name = input("\nEnter sales person name [e.g. John]: ")
                level = int(input("Enter Level [e.g. 1]: "))
                hours = int(input("Enter Hours Worked [e.g. 10]: "))
                amount = int(input("Enter Sales Amount [e.g. 2000]: "))
                sales_data.append([name, level, hours, amount])
                break
            except:
                print("\nWrong Input. Enter same record again.\n")
   
    # Calculate commissions and hourly wages of each sale person
    commissions = functions.calculate_commissions(sales_data)
    hourly_wages = functions.calculate_hourly_wages(sales_data)
    gross = functions.calculate_gross_pays(commissions, hourly_wages)
    
    # Calculate combined commissions, hourly_wages, and total amount paid
    combined_commissions, combined_hourly_wages, total_amount_paid = functions.get_combined_calculations(commissions, hourly_wages)
    
    # Output
    print("\nTotal commissions for all salespersons combined: ", "${:,.2f}".format(combined_commissions))
    print("Total hourly wages for all salespersons combined: ", "${:,.2f}".format(combined_hourly_wages))
    print("Total amount payed to all employees combined: ", "${:,.2f}".format(total_amount_paid))

    for i in range(total_persons):
        print("\nName: ", sales_data[i][0])
        print("Wage: ", "${:,.2f}".format(hourly_wages[i]))
        print("Commission: ", "${:,.2f}".format(commissions[i]))
        print("Gross Pay: ", "${:,.2f}".format(gross[i]), "\n")


if __name__ == "__main__":
    main()
