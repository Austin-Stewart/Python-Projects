
def calculate_commissions(sales_persons):
    #Function calculates commission of each sale person in list
    commissions = []
    for sale_person in sales_persons:  
        if sale_person[1] == 1:
            if sale_person[3] <= 2500:
                commissions.append((sale_person[3] * 4.5) / 100)
            elif 2500 < sale_person[3] < 4500:
                commissions.append((sale_person[3] * 6.25) / 100)
            elif sale_person[3] >= 4500:
                commissions.append((sale_person[3] * 9.25) / 100)
        elif sale_person[1] == 2:
            if sale_person[3] <= 2500:
                commissions.append((sale_person[3] * 5.75) / 100)
            elif sale_person[3] > 2500:
                commissions.append((sale_person[3] * 7.25) / 100)
        elif sale_person[1] == 3:
            commissions.append((sale_person[3] * 7.75) / 100)
        elif sale_person[1] == 4:
            commissions.append((sale_person[3] * 9.25) / 100)
        else:
            print(sale_person[0], "Invalid level. No commission will be paid.")
            commissions.append(0)
    return commissions
    
    
def calculate_hourly_wages(sales_persons):
    #Function calculates hourly wages of all sales persons
    hourly_wages = []
    for sale_person in sales_persons:
        if sale_person[1] == 1:
            if sale_person[2] <= 40:
                hourly_wages.append(sale_person[2] * 13.5)
            else:
                wage = ((sale_person[2] - 40) * 13.5 * 1.5) + 13.5 * 40
                hourly_wages.append(wage)
        elif sale_person[1] == 2:
            if sale_person[2] <= 40:
                hourly_wages.append(sale_person[2] * 15.75)
            else:
                wage = ((sale_person[2] - 40) * 15.75 * 1.5) + 15.75 * 40
                hourly_wages.append(wage)
        elif sale_person[1] == 3:
            if sale_person[2] <= 40:
                hourly_wages.append(sale_person[2] * 18.25)
            else:
                wage = ((sale_person[2] - 40) * 18.25 * 1.5) + 18.25 * 40
                hourly_wages.append(wage)
        elif sale_person[1] == 4:
            if sale_person[2] <= 40:
                hourly_wages.append(sale_person[2] * 20.75)
            else:
                wage = ((sale_person[2] - 40) * 20.75 * 1.5) + 20.75 * 40
                hourly_wages.append(wage)
        else:
            print(sale_person[0], "Invalid level. No hourly wage will be paid.")
            hourly_wages.append(0)
    return hourly_wages


def calculate_gross_pays(commissions, hourly_wages):
    #Function calculates gross pay of each sale person
    gross_pays = []
    for i in range(len(commissions)):
        pay = commissions[i] + hourly_wages[i]
        gross_pays.append(pay)
    return gross_pays
    
    
def get_combined_calculations(commissions, hourly_wages):
    #Function calculates combined sales persons commissions, hourly_wages, and total amount paid
    combined_commission = sum(commissions)
    combined_hourly_wages = sum(hourly_wages)
    total_amount_paid = combined_commission + combined_hourly_wages
    return combined_commission, combined_hourly_wages, total_amount_paid
